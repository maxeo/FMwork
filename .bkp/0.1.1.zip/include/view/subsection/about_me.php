<?php
Pageloader::addTag("!DOCTYPE html", NULL, 0, 1);
Pageloader::ln();
Pageloader::addTag("html", NULL, 0, 1);
Pageloader::ln();
Pageloader::addElement("templateHead");
Pageloader::ln();
Pageloader::addTag("body", NULL, 0, 1);
Pageloader::ln();
Pageloader::addTag(' div id="wrapper"', NULL, 0, 1);
Pageloader::ln();
Pageloader::addElement("templateHeader");
Pageloader::ln();
Pageloader::addElement("templateNav");
Pageloader::ln();
Pageloader::addTag('     div id="main"', NULL, 0, 1);
Pageloader::ln();
Pageloader::addElement("templateSubsectionAboutMe");
Pageloader::ln();
Pageloader::addTag('     div', NULL, 1, 0);
Pageloader::ln();
Pageloader::addElement("templateFooter");
Pageloader::ln();
Pageloader::addTag(' div', NULL, 1, 0);

?>