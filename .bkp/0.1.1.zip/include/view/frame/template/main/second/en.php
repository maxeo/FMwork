							<section id="worksdone" class="main special">
								<header class="major">
									<h2>Works Done</h2>
                                                                        <p>Below you can find some of the programs that I made over time</p>
								</header>
								<ul class="statistics">
									<li class="style1">
										<span class="icon fa-cogs"></span>
										<strong>MFwork</strong> Framework in php
									</li>
									<li class="style2">
										<span class="icon fa-globe"></span>
										<strong>I Folletti del Bosco</strong> Web site
									</li>
									<li class="style3">
										<span class="icon fa-cloud"></span>
                                                                                <strong>MyCloud</strong> File Manager written in HTML5
									</li>
									<li class="style4">
										<span class="icon fa-spinner"></span>
										<strong>BrainGame</strong> Improve your ability to count
									</li>
									<li class="style5">
										<span class="icon fa-puzzle-piece"></span>
										<strong>Other projects...</strong>
									</li>
								</ul>
								<p class="content">During the course of my career I have created some programs some of which I can share their work with you. Some of them are complete, while others have I decided to limit their functions for reasons of security, if you contact me I can show you the most "powerful features", but given their strength can be harmful if exploited badly.</p>
								<footer class="major">
									<ul class="actions">
										<li><a href="generic.html" class="button">Leggi Ancora</a></li>
									</ul>
								</footer>
							</section>