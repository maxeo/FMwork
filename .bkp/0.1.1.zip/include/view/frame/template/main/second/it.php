							<section id="lavorisvolti" class="main special">
								<header class="major">
									<h2>Lavori Svolti</h2>
                                                                        <p>Qui sotto è possibile trovare alcuni dei programmi che ho creato nel corso del tempo</p>
								</header>
								<ul class="statistics">
									<li class="style1">
										<span class="icon fa-cogs"></span>
										<strong>MFwork</strong> Framework in php
									</li>
									<li class="style2">
										<span class="icon fa-globe"></span>
										<strong>I Folletti del Bosco</strong> Sito web
									</li>
									<li class="style3">
										<span class="icon fa-cloud"></span>
                                                                                <strong>MyCloud</strong> FileManager scritto in HTML5
									</li>
									<li class="style4">
										<span class="icon fa-spinner"></span>
										<strong>BrainGame</strong> Migliora la tua capacità di contare
									</li>
									<li class="style5">
										<span class="icon fa-puzzle-piece"></span>
										<strong>Altri progetti...</strong>
									</li>
								</ul>
								<p class="content">Durante il corso delle mie attività ho creato alcuni programmi alcuni dei quali posso condividere il loro funzionamento con il lettore. Alcuni di essi sono completi, mentre altri ho deciso di limitare le loro funzioni per ragioni di sicurezza, se mi contattate potrò illustrarvi le funzioni più "potenti", ma che data la loro forza possono arrecare danno se sfruttati male.</p>
								<footer class="major">
									<ul class="actions">
										<li><a href="generic.html" class="button">Leggi Ancora</a></li>
									</ul>
								</footer>
							</section>