							<section id="presentazione" class="main">
								<div class="spotlight">
									<div class="content">
										<header class="major">
											<h2>Su di me...</h2>
										</header>
										<p>
										    Mi chiamo Mattteo Burbui, sono nato a Figline Valdarno. Al momento vivo a San Giovanni Valdarno.<br>
										    Ho frequentato il liceo socio-psico pedagogico, ma non era la strada, così durante il periodo scolastico ho studiato HTML, PHP e JavaScript.<br>
										    Ho lavorato come tipografo e qui ho fatto alcuni piccoli programmi per l'azienda come calcolatrici personalizzati, diario di lavoro o altri programmi di utilità.<br>
										</p>
										<ul class="actions">
											<li><a href="<?php echo Pageloader::pageFromTarget("about-me", false,"it");  ?>" class="button">Leggi Ancora</a></li>
										</ul>
									</div>
									<span class="image"><img src="/imgs/me.jpg" alt="Matteo Burbui" title="Matteo Burbui" /></span>
								</div>
							</section>