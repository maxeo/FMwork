						<footer id="footer">
						<section>
							<h2>Fast contact</h2>
                                                        <form action="/it/sandMail" method="post">
                                                            <input type="email" placeholder="Write your email address"><br>
                                                            <textarea placeholder="Write the body of the message"></textarea>
                                                            <br>
                                                            <ul class="actions">
                                                                <li><input type="submit" value="Contact me"></li>
                                                            </ul>
                                                        </form>
						</section>
						<section>
							<h2>Contacts</h2>
							<dl class="alt">
								<dt>Address</dt>
								<dd>7 Via Concetto Marchesi &bull; San Giovanni Valdarno, AREZZO 52027 &bull; ITALY</dd>
								<dt>Phone</dt>
								<dd>(0039) 055-0456284</dd>
                                                                <dd>(0039) 392-0560787</dd>
								<dt>Email</dt>
                                                                <dd class="mailBoxm"><a href="#" class="mailBoxm"></a><img src="/imgs/infomail.png"></dd>
							</dl>
							<ul class="icons">
                                                            <li><a href="https://fb.com/maxeo90" class="icon fa-facebook alt"><span class="label">Facebook</span></a></li>
                                                            <li><a href="https://twitter.com/@maxeo90" class="icon fa-twitter alt"><span class="label">Twitter</span></a></li>
							</ul>
						</section>
						<p class="copyright">&copy; Maxeo.it. Design: <a href="https://html5up.net">HTML5 UP</a> Animation: <a href="http://maxeo.it">Maxeo</a>.</p>
					</footer>