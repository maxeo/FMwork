							<section id="introduction" class="main">
								<div class="spotlight">
									<div class="content">
										<header class="major">
											<h2>About me...</h2>
										</header>
                                                                            <p>My name is Mattteo Burbui, I was born in Figline Valdarno. At the moment I live in San Giovanni Valdarno.<br>
                                                                                In high school I studied pedagogy, but it wasn't my way, so during the school time I studied HTML, PHP and JavaScript.<br>
                                                                            I worked as a typesetter and here I made some little programs for the company like custom calculators, work diary or utility.
                                                                            
                                                                            </p>
										<ul class="actions">
											<li><a href="generic.html" class="button">Read More</a></li>
										</ul>
									</div>
									<span class="image"><img src="/imgs/me.jpg" alt="" /></span>
								</div>
							</section>