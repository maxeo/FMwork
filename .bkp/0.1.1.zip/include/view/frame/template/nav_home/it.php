					<nav id="nav">
						<ul>
							<li><a class="nav_section" href="#presentazione">Presentazione</a></li>
							<li><a class="nav_section" href="#competenze">Competenze</a></li>
							<li><a class="nav_section" href="#lavorisvolti">Lavori Svolti</a></li>
							<li><a href="<?php echo Pageloader::pageFromTarget(Pageloader::getData("target"), false,"en");  ?>"><img style="width: 24px;" src="/imgs/flagEN.svg" alt="In Enlish"></a></li>
						</ul>
					</nav>