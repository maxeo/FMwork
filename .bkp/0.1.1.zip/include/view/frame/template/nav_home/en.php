					<nav id="nav">
						<ul>
							<li><a class="nav_section"  href="#introduction" class="active">Introduction</a></li>
							<li><a class="nav_section"  href="#skills">Skills</a></li>
							<li><a class="nav_section"  href="#worksdone">Works Done</a></li>
							<li><a href="<?php echo Pageloader::pageFromTarget(Pageloader::getData("target"), false,"it");  ?>"><img style="width: 24px;"><img style="width: 24px;" src="/imgs/flagIT.svg" alt="In Italiano"></a></li>
						</ul>
					</nav>